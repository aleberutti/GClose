package com.becafe.gclose.Model;

public class ModelTest {
}
