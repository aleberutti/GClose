package com.becafe.gclose.Controller;

import android.view.View;

public interface IRecyclerViewClickListener {
    void onClick(View view, int postition);
}
